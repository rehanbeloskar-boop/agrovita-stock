const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcd1234"
};
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// ----------------- Core Logic -----------------
let state = { customers: [] };

function today() { return new Date().toISOString().slice(0, 10); }
function addDays(d, days) { let t = new Date(d); t.setDate(t.getDate() + days); return t.toISOString().slice(0, 10); }
function paid(inv) { return inv.payments.reduce((s, p) => s + (p.cash || 0) + (p.upi || 0) + (p.cheque || 0), 0); }
function bal(inv) { return inv.amount - paid(inv); }
function status(inv) {
  if (bal(inv) <= 0) return "Paid";
  if (paid(inv) > 0) return "Part Paid";
  if (new Date(inv.due) <= new Date() && bal(inv) > 0) return "Overdue";
  return "Unpaid";
}

// Add Customer
async function addCustomer() {
  let name = document.getElementById("newName").value.trim();
  let mobile = document.getElementById("newMobile").value.trim();
  let rest = document.getElementById("newRest").value.trim();
  let zone = document.getElementById("newZone").value.trim();
  if (!name || !mobile || !rest || !zone) return alert("Enter all details");
  let id = "cust_" + Math.random().toString(36).slice(2, 7);
  let cust = { id, name, mobile, restaurant: rest, zone, invoices: [], payments: [] };
  await db.collection("customers").doc(id).set(cust);
}

// Add Invoice
async function addInvoice(custId) {
  let cust = state.customers.find(c => c.id === custId);
  let no = document.getElementById("invNo_" + custId).value || `INV-${cust.invoices.length + 1}`;
  let d = document.getElementById("invDate_" + custId).value || today();
  let amt = Number(document.getElementById("invAmt_" + custId).value); if (!amt) return;
  let cd = Number(document.getElementById("credit_" + custId).value || 0);
  let inv = { id: Math.random().toString(36).slice(2, 9), no, date: d, due: addDays(d, cd), amount: amt, payments: [] };
  await db.collection("customers").doc(custId).update({
    invoices: firebase.firestore.FieldValue.arrayUnion(inv)
  });
}

// Add Payment
async function pay(custId, invId) {
  let cust = state.customers.find(c => c.id === custId);
  let inv = cust.invoices.find(i => i.id === invId);
  let cash = Number(prompt("Cash (₹)", 0)) || 0;
  let upi = Number(prompt("UPI (₹)", 0)) || 0;
  let cheque = Number(prompt("Cheque (₹)", 0)) || 0;
  if (cash + upi + cheque <= 0) return;
  let payObj = { cash, upi, cheque, date: today(), invNo: inv.no };
  inv.payments.push(payObj);
  await db.collection("customers").doc(custId).update({
    invoices: cust.invoices,
    payments: firebase.firestore.FieldValue.arrayUnion(payObj)
  });
}

// WhatsApp Reminder
function sendWhatsApp(custId) {
  let cust = state.customers.find(c => c.id === custId);
  let totalBal = 0, lines = [`Hello ${cust.name} (${cust.restaurant}),`, "Pending Invoices:"];
  cust.invoices.forEach(inv => {
    if (bal(inv) > 0) {
      lines.push(`• ${inv.no}: ₹${bal(inv)} (Due ${inv.due})`);
      totalBal += bal(inv);
    }
  });
  lines.push(`Total Pending: ₹${totalBal}`);
  window.open(`https://wa.me/91${cust.mobile}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
}

// Render Customer Cards
function renderCustomerCards() {
  let div = document.getElementById("customerList"); div.innerHTML = "";
  state.customers.forEach(c => {
    let out = 0; c.invoices.forEach(inv => { out += bal(inv); });
    let card = document.createElement("div");
    card.className = "customer-card";
    card.innerHTML = `<b>${c.name}</b><br>📱 ${c.mobile}<br>🍴 ${c.restaurant}<br>🌍 ${c.zone}<hr>
    💰 <b>Pending: ₹${out}</b><br><br>
    <button onclick="showPage('${c.id}')">👁 View</button>`;
    div.appendChild(card);
  });
}

// Render Pages
function renderPages() {
  let div = document.getElementById("pages"); div.innerHTML = "";
  state.customers.forEach(c => {
    let page = document.createElement("div"); page.className = "page"; page.id = c.id;
    page.innerHTML = `<h2>${c.name} (📱 ${c.mobile}, 🍴 ${c.restaurant}, 🌍 ${c.zone})</h2>
    <button onclick="sendWhatsApp('${c.id}')">📩 WhatsApp</button>
    <div class="card"><h3>Create Invoice</h3>
      <input id="invNo_${c.id}" placeholder="Invoice No"><br>
      <input type="date" id="invDate_${c.id}"><br>
      <input type="number" id="invAmt_${c.id}" placeholder="Amount ₹"><br>
      <input type="number" id="credit_${c.id}" value="30"> Credit Days<br>
      <button onclick="addInvoice('${c.id}')">Add Invoice</button>
    </div>
    <div class="card"><h3>Invoices</h3>
      <table><thead><tr><th>No</th><th>Date</th><th>Due</th><th>Amt</th><th>Paid</th><th>Bal</th><th>Status</th><th>Pay</th></tr></thead>
      <tbody>${c.invoices.map(inv => `<tr><td>${inv.no}</td><td>${inv.date}</td><td>${inv.due}</td>
      <td>₹${inv.amount}</td><td>₹${paid(inv)}</td><td>₹${bal(inv)}</td><td>${status(inv)}</td>
      <td><button onclick="pay('${c.id}','${inv.id}')">Pay</button></td></tr>`).join("")}</tbody></table>
    </div>`;
    div.appendChild(page);
  });
}

// Show Page
function showPage(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// Show Summary
function showSummary() {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById("summaryPage").classList.add("active");
  updateSummary();
}

// Update Boss Summary
function updateSummary() {
  let tbody = document.getElementById("summaryBody"); tbody.innerHTML = "";
  let currentMonth = today().slice(0, 7);
  state.customers.forEach(c => {
    let total = 0, rec = 0, out = 0, mCash = 0, mUpi = 0, mCheque = 0;
    c.invoices.forEach(inv => { total += inv.amount; rec += paid(inv); out += bal(inv); });
    c.payments.forEach(p => { if (p.date.startsWith(currentMonth)) { mCash += p.cash; mUpi += p.upi; mCheque += p.cheque; } });
    let tr = document.createElement("tr");
    tr.innerHTML = `<td>${c.name}</td><td>${c.mobile}</td><td>${c.restaurant}</td><td>${c.zone}</td>
    <td>₹${total}</td><td>₹${rec}</td><td>₹${out}</td><td>₹${out}</td>
    <td>₹${mCash}</td><td>₹${mUpi}</td><td>₹${mCheque}</td>`;
    tbody.appendChild(tr);
  });
}

// 🔥 Live Sync with Firestore
db.collection("customers").onSnapshot(snapshot => {
  state.customers = snapshot.docs.map(doc => doc.data());
  renderCustomerCards(); renderPages();
});
