// Global arrays
let categories = [], products = [], stockHistory = [], categoryId = 1, productId = 1;

// ===== CATEGORY FUNCTIONS =====
function addCategory() {
    const name = document.getElementById('categoryName').value.trim();
    if (!name) return alert('Enter category name!');
    categories.push({ id: categoryId++, name });
    document.getElementById('categoryName').value = '';
    renderCategories();
    renderCategoryOptions();
    renderProductSelect();
}

function renderCategories() {
    const table = document.getElementById('categoryTable');
    table.innerHTML = '<tr><th>ID</th><th>Category Name</th><th>Actions</th></tr>';
    categories.forEach(cat => {
        table.innerHTML += `<tr>
            <td>${cat.id}</td><td>${cat.name}</td>
            <td><button class="btn" onclick="deleteCategory(${cat.id})">Delete</button></td>
        </tr>`;
    });
}

function renderCategoryOptions() {
    const select = document.getElementById('productCategory');
    const filter = document.getElementById('filterCategory');
    select.innerHTML = ''; 
    filter.innerHTML = '<option value="all">All</option>';
    categories.forEach(cat => {
        select.innerHTML += `<option value="${cat.name}">${cat.name}</option>`;
        filter.innerHTML += `<option value="${cat.name}">${cat.name}</option>`;
    });
}

function renderProductSelect() {
    const select = document.getElementById('productSelect');
    select.innerHTML = '';
    products.forEach(p => {
        select.innerHTML += `<option value="${p.name}|${p.category}">${p.name} (${p.category})</option>`;
    });
}

function deleteCategory(id) {
    const cat = categories.find(c => c.id === id);
    categories = categories.filter(c => c.id !== id);
    products = products.filter(p => p.category !== cat.name);
    stockHistory = stockHistory.filter(s => s.category !== cat.name);
    renderCategories(); renderCategoryOptions(); renderProducts(); renderStockHistory(); renderProductSelect();
}

// ===== STOCK IN =====
function stockIn() {
    const name = document.getElementById('productName').value.trim();
    const qty = parseInt(document.getElementById('productQty').value);
    const threshold = parseInt(document.getElementById('stockThreshold').value);
    const category = document.getElementById('productCategory').value;
    if (!name || isNaN(qty)) return alert('Enter product name and quantity!');
    const now = new Date(), date = now.toLocaleDateString(), time = now.toLocaleTimeString();
    const existing = products.find(p => p.name === name && p.category === category);
    if (existing) {
        existing.qty += qty; existing.threshold = threshold; existing.lastUpdated = `${date} ${time}`;
        stockHistory.push({ date, time, product: name, category, stockIn: qty, stockOut: 0, qtyAfter: existing.qty });
    } else {
        products.push({ id: productId++, name, qty, threshold, category, lastUpdated: `${date} ${time}` });
        stockHistory.push({ date, time, product: name, category, stockIn: qty, stockOut: 0, qtyAfter: qty });
    }
    document.getElementById('productName').value = '';
    document.getElementById('productQty').value = '';
    renderProducts(); renderStockHistory(); renderProductSelect();
    const checkQty = existing ? existing.qty : qty;
    if (checkQty <= threshold) alert(`Stock Alert! "${name}" is low.`);
}

// ===== STOCK OUT =====
function stockOut() {
    const val = document.getElementById('productSelect').value;
    if (!val) return alert('Select a product!');
    const [name, category] = val.split('|');
    const qtyOut = parseInt(document.getElementById('stockOutQty').value);
    if (isNaN(qtyOut) || qtyOut <= 0) return alert('Enter valid quantity!');
    const product = products.find(p => p.name === name && p.category === category);
    if (!product || product.qty < qtyOut) return alert('Not enough stock!');
    product.qty -= qtyOut;
    const now = new Date(), date = now.toLocaleDateString(), time = now.toLocaleTimeString();
    product.lastUpdated = `${date} ${time}`;
    stockHistory.push({ date, time, product: name, category, stockIn: 0, stockOut: qtyOut, qtyAfter: product.qty });
    document.getElementById('stockOutQty').value = '';
    renderProducts(); renderStockHistory();
    if (product.qty <= product.threshold) alert(`Stock Alert! "${product.name}" is low.`);
}

// ===== RENDER PRODUCTS =====
function renderProducts() {
    const table = document.getElementById('stockTable');
    const filterValue = document.getElementById('filterCategory').value;
    table.innerHTML = `<tr>
        <th>ID</th><th>Product Name</th><th>Category</th><th>Quantity</th>
        <th>Threshold</th><th>Last Updated</th><th>Actions</th>
    </tr>`;
    products.forEach(p => {
        if (filterValue !== 'all' && p.category !== filterValue) return;
        const lowStock = p.qty <= p.threshold ? 'low-stock' : '';
        table.innerHTML += `<tr class="${lowStock}">
            <td>${p.id}</td><td>${p.name}</td><td>${p.category}</td>
            <td>${p.qty}</td><td>${p.threshold}</td><td>${p.lastUpdated}</td>
            <td>
                <button class="btn" onclick="promptAddQuantity(${p.id})">Add Quantity</button>
                <button class="btn" onclick="editProduct(${p.id})">Edit</button>
                <button class="btn" onclick="deleteProduct(${p.id})">Delete</button>
            </td>
        </tr>`;
    });
}

// ===== STOCK HISTORY =====
function renderStockHistory() {
    const table = document.getElementById('stockHistoryTable');
    table.innerHTML = `<tr>
        <th>Date</th><th>Time</th><th>Product</th><th>Category</th>
        <th>Stock In</th><th>Stock Out</th><th>Quantity After</th>
    </tr>`;
    stockHistory.forEach(s => {
        table.innerHTML += `<tr>
            <td>${s.date}</td><td>${s.time}</td><td>${s.product}</td><td>${s.category}</td>
            <td>${s.stockIn}</td><td>${s.stockOut}</td><td>${s.qtyAfter}</td>
        </tr>`;
    });
}

// ===== ADD QUANTITY =====
function promptAddQuantity(id) {
    const prod = products.find(p => p.id === id);
    if (!prod) return;
    let addQty = parseInt(prompt(`Enter quantity to add for "${prod.name}":`, '0'));
    if (isNaN(addQty) || addQty <= 0) return alert('Invalid quantity!');
    prod.qty += addQty;
    const now = new Date();
    prod.lastUpdated = `${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
    stockHistory.push({ date: now.toLocaleDateString(), time: now.toLocaleTimeString(), product: prod.name, category: prod.category, stockIn: addQty, stockOut: 0, qtyAfter: prod.qty });
    renderProducts(); renderStockHistory();
    if (prod.qty <= prod.threshold) alert(`Stock Alert! "${prod.name}" is low.`);
}

// ===== EDIT PRODUCT =====
function editProduct(id) {
    const prod = products.find(p => p.id === id);
    if (!prod) return;
    const newName = prompt("Edit Product Name:", prod.name);
    if (!newName) return;
    const newCategory = prompt("Edit Category:", prod.category);
    if (!newCategory) return;
    const newQty = parseInt(prompt("Edit Quantity:", prod.qty));
    if (isNaN(newQty)) return;
    const newThreshold = parseInt(prompt("Edit Threshold:", prod.threshold));
    if (isNaN(newThreshold)) return;
    prod.name = newName;
    prod.category = newCategory;
    prod.qty = newQty;
    prod.threshold = newThreshold;
    const now = new Date();
    prod.lastUpdated = `${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
    stockHistory.push({ date: now.toLocaleDateString(), time: now.toLocaleTimeString(), product: prod.name, category: prod.category, stockIn: 0, stockOut: 0, qtyAfter: prod.qty });
    renderProducts(); renderStockHistory(); renderProductSelect();
}

// ===== DELETE PRODUCT =====
function deleteProduct(id) {
    products = products.filter(p => p.id !== id);
    renderProducts(); renderProductSelect();
}

// ===== EXPORT CSV =====
function exportStockHistory() {
    if (stockHistory.length === 0) return alert('No stock history to export!');
    let csv = 'Date,Time,Product,Category,Stock In,Stock Out,Quantity After\n';
    stockHistory.forEach(s => {
        csv += `${s.date},${s.time},${s.product},${s.category},${s.stockIn},${s.stockOut},${s.qtyAfter}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Agrovita_Stock_History_${new Date().toLocaleDateString()}.csv`;
    a.click();
}

// ===== PRINT STOCK HISTORY =====
function printStockHistory() {
    const printContent = document.getElementById('stockHistoryTable').outerHTML;
    const newWin = window.open('', '', 'width=900,height=600');
    newWin.document.write('<html><head><title>Stock History</title>');
    newWin.document.write('<style>table{width:100%;border-collapse:collapse;}th,td{border:1px solid #ccc;padding:8px;text-align:center;}th{background:#28a745;color:white;}</style>');
    newWin.document.write('</head><body>');
    newWin.document.write(printContent);
    newWin.document.write('</body></html>');
    newWin.document.close();
    newWin.print();
}
